/* 
 * File:   main.cpp
 * Author: Nicholas Valdez
  * Created on October , 2017, 8:30pm
 * purpose: creating a class template
 */

//system libraries
#include <iostream>     //Input/Output library
using namespace std;   // standard name-space under which system libraries reside

// user libraries

// global constants - not variables only math/science/conversions constants

// function prototypes

//execution begins here:
int main(int argc, char** argv) {
    // declare variables
    int one, two //minimum and maximum
    //initialize variables
    cout<<"please enter two numbers"<<endl;
    cout<<"number 1: "<<endl;
    cin>>one<<endl;
    cout<<"number 2: "<<endl;
    cin>>two<<endl;
            
    //argumments
    if (one>two)
        cout<<one<<","<<two<<endl;
    else 
        cout<<two<<","<<one<<endl;
    
    
    
    //exit the program  
    
    return 0;
}

