/* 
 * File:   main.cpp
 * Author: Nicholas Valdez
  * Created on October , 2017, 8:30pm
 * purpose: record of a pole vaulter
 */

//system libraries
#include <iostream>     //Input/Output library
#include <cmath>       // used for calculations
using namespace std;   // standard name-space under which system libraries reside

// user libraries

// global constants - not variables only math/science/conversions constants


// function prototypes

//execution begins here:
int main(int argc, char** argv) {
    // declare variables
    int date1, date2, date3; //date of the vaults
    int pole1, pole2, pole3; // heights of the vault
    int name; // name of the vaulter
    
   
    // user information
    cout<<"please enter the name of the vaulter"<<endl;
    cin>>name<<endl;
    cout<<"please enter the date and height of vault 1"<<endl;
    cout<<"date:"<<endl;
    cin>>date1<<endl;
    cout<<"height:"<<endl;
    cin>>pole1<<endl;
    cout<<"please enter the date and height of vault 2"<<endl;
    cout<<"date:"<<endl;
    cin>>date2<<endl;
    cout<<"height:"<<endl;
    cin>>pole2<<endl;
    cout<<"please enter the date and height of vault 3"<<endl;
    cout<<"date:"<<endl;
    cin>>date3<<endl;
    cout<<"height:"<<endl;
    cin>>pole3<<endl;
                
                
    //argument
    if (5>pole1, pole2, pole3>2) 
        cout<<"sorry but the height is impossible"<<endl;
        cout<<"please restart nd eneter plausibe heights"<<endl;
    if (pole1>pole2>pole3)
        cout<<name<<" best jumps are listed as:"<<endl;
        cout<<pole1<<" on "<<date1<<endl;
        cout<<pole2<<" on "<<date2<<endl;
        cout<<pole3<<" on "<<date3<<endl;
    if (pole3>pole2>pole1)
        cout<<name<<" best jumps are listed as:"<<endl;
        cout<<pole3<<" on "<<date3<<endl;
        cout<<pole2<<" on "<<date2<<endl;
        cout<<pole1<<" on "<<date1<<endl;
    if (pole3>pole1>pole2)
        cout<<name<<" best jumps are listed as:"<<endl;
        cout<<pole3<<" on "<<date3<<endl;
        cout<<pole1<<" on "<<date1<<endl;
        cout<<pole2<<" on "<<date2<<endl;
    if (pole1>pole3>pole2)
        cout<<name<<" best jumps are listed as:"<<endl;
        cout<<pole1<<" on "<<date1<<endl;
        cout<<pole3<<" on "<<date3<<endl;
        cout<<pole2<<" on "<<date2<<endl;
    if (pole2>pole1>pole3)
        cout<<name<<" best jumps are listed as:"<<endl;
        cout<<pole2<<" on "<<date2<<endl;
        cout<<pole1<<" on "<<date1<<endl;
        cout<<pole3<<" on "<<date3<<endl;
    if (pole2>pole3>pole1)
        cout<<name<<" best jumps are listed as:"<<endl;
        cout<<pole2<<" on "<<date2<<endl;
        cout<<pole3<<" on "<<date3<<endl;
        cout<<pole1<<" on "<<date1<<endl;   
                  
    //exit the program  
    
    return 0;
}

