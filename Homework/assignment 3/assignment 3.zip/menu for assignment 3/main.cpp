/* 
 * File:   main.cpp
 * Author: Nicholas Valdez
  * Created on october 10, 2017, 11:00 pm 
 * purpose: create a menu
 */

//system libraries
#include <iostream>     //Input/Output library
#include <cmath>
using namespace std;   // standard name-space under which system libraries reside

// user libraries

// global constants - not variables only math/science/conversions constants

// function prototypes

//execution begins here:
int main(int argc, char** argv) {
    // declare variables
    int newt, area, twonum, racer;
    int pole, magdat, bmi, softwr;
    
    // give value for each problem
    newt = 1
    area = 2
    twonum = 3
    racer = 4
    pole = 5
    magdat = 6
    bmi = 7
    softwr = 8
    book = 9
    
    // menu for problems
    cout<<"please enter the numerical value to pick a problem"<<endl;
    cout<<"1. weight to newtons"<<endl;
    cout<<"2. area of two triangles"<<endl;
    cout<<"3. which is greater"<<endl;
    cout<<"4. the race for first"<<endl;
    cout<<"5. the pole vault record"<<endl;
    cout<<"6. the  magical date"<<endl;
    cout<<"7. BMI"<<endl;
    cout<<"8. software in bulk"<<endl;
    cout<<"9. book club points"<<endl;
    cin>>choice;
   
    
    case newt:
{
    // declare variables
    int newt, wght // newtons and weight
    
    // user information
    cout<<"please provide the wight of object"<<endl;
    cin>>wght<<endl;
    
    //calculations
    newt = wght*9.8
             
    //argument
    if (newt>1000)
        cout<<"the object is too heavy "<<endl;
    if (10>newt)
        cout<<"the object is too light"<<endl;
    else
        cout<<newt<<" this is your mass in newtons"<<endl;
   
        
        
   
                  
    //exit the program  
    
    return 0;
}

case area:
{
    // declare variables
    int area1, area2; // this allows us to store the two ares to solve the problem
    int lnth1, lnth2; // needed for the area
    int wdth1, wdth2; // needed for the area 
    
    // user information
    cout<<"please provide the length of traingle 1 and traingle 2"<<endl;
    cout<<"traingle 1 length is: "<<endl;
    cin>>lnth1<<endl;
    cout<<"traingle 2 length is: "<<endl;
    cin>>lnth2<<endl;
    cout<<"please provide the width of traingle 1 and traingle 2"<<endl;
    cout<<"traingle 1 width is: "<<endl;
    cin>>wdth1<<endl;
    cout<<"traingle 2 width is: "<<endl;
    cin>>wdth2<<endl;
    
    // calculations
    area1 = lnth1 * wdth1;
    area2 = lnth2 * wdth2;
    
    //argument
    if (area1>area2)
        cout<<"traingle 1 is greater than traingle 2"<<endl;
                cout<<area1<<","<<area2<<endl;
    if (area2>area1)
        cout<<"traingle 2 is greater than triangle 1"<<endl;
                cout<<area2<<","<<area1<<endl;
    if (area1=area2)
        cout<<"traingle 1 and traingle 2 are equal"<<endl;
               cout<<area1<<","<<area2<<endl; 
    
    
    
    
    //exit the program  
    
    return 0;
}
case twonum:
{
    // declare variables
    int one, two //minimum and maximum
    //initialize variables
    cout<<"please enter two numbers"<<endl;
    cout<<"number 1: "<<endl;
    cin>>one<<endl;
    cout<<"number 2: "<<endl;
    cin>>two<<endl;
            
    //argumments
    if (one>two)
        cout<<one<<","<<two<<endl;
    else 
        cout<<two<<","<<one<<endl;
    
    
    
    //exit the program  
    
    return 0;
}
    
    case racer:
            {
    // declare variables
    int run1, run2, run3; // runner 1, 2, and 3
    float time1, time2, time3; // time for 1, 2, and 3
    
    // user information
    cout<<"please provide the name of runner 1"<<endl;
    cin>>run1<<endl;
    cout<<"please provide the time of runner 1"<<endl;
    cin>>time1<<endl;
    cout<<"please provide the name of runner 2"<<endl;
    cin>>run2<<endl;
    cout<<"please provide the time of runner 2"<<endl;
    cin>>time2<<endl;
    cout<<"please provide the name of runner 3"<<endl;
    cin>>run3<<endl;
    cout<<"please provide the time of runner 3"<<endl;
    cin>>time3<<endl;
         
    //argument
    if (time1>time2>time3)
        cout<<"the winning order is: "<<endl;
        cout<<run1<<","<<run2<<","<<run3<<endl;
    if (time3>time2>time1)
        cout<<"the winning order is: "<<endl;
        cout<<run3<<","<<run2<<","<<run1<<endl;
    if (time1>time3>time2)
        cout<<"the winning order is: "<<endl;
        cout<<run1<<","<<run3<<","<<run2<<endl;
    if (time3>time1>time2)
        cout<<"the winning order is: "<<endl;
        cout<<run3<<","<<run1<<","<<run2<<endl; 
    if (time2>time3>time1)
        cout<<"the winning order is: "<<endl;
        cout<<run2<<","<<run3<<","<<run1<<endl;
    if (time2>time1>time3)
        cout<<"the winning order is: "<<endl;
        cout<<run2<<","<<run1<<","<<run3<<endl;
    if (time1, time2, time3 <=0)
        cout<<"impossible time, please follow instructions"<<endl;
        
        
   
                  
    //exit the program  
    
    return 0;
}
    case softwr:
{
    // declare variables
    float prc1, prc2, prc3, prc4; 
    // different prices for different amount bought
    int quant; // quantity bought
    int sprc; // stnadard price
    
    //initialize
    sprc = 99; // given by problem
    
    // user information
    cout<<"the software being purchased offers a discount on bulk sales"<<endl;
    cout<<" please enters the amount of software you wna to purchase"<<endl;
    cin>>quant<<endl;
                
    //argument
    if (quant<10)
        cout<<" sorry no discount"
        cout<<"your total price is $ "<<sprc<<endl;
    if (19>quant>=10)
        cout<<"you have received a discount of 20%"<<endl;
            prc1 = sprc*.2
        cout<<"your total price is $ "<<prc1<<endl;
    if (49>quant>=20)
        cout<<"you have received a discount of 30%"<<endl;
            prc2 = sprc*.3
        cout<<"your total price is $ "<<prc2<<endl;
    if (99>=quant>=50)
        cout<<"you have recieved a discount of 40%"
                prc3 = sprc*.4
        cout<<"your total price is $ "<<prc3<<endl;
    if (quant>=100)
        cout<<"you have received a discount of 50%"<<endl;
            prc1 = sprc*.5
        cout<<"your total price is $ "<<prc4<<endl;
   
        
        
   
                  
    //exit the program  
    
    return 0;
}

    case pole:
{
    // declare variables
    int date1, date2, date3; //date of the vaults
    int pole1, pole2, pole3; // heights of the vault
    int name; // name of the vaulter
    
   
    // user information
    cout<<"please enter the name of the vaulter"<<endl;
    cin>>name<<endl;
    cout<<"please enter the date and height of vault 1"<<endl;
    cout<<"date:"<<endl;
    cin>>date1<<endl;
    cout<<"height:"<<endl;
    cin>>pole1<<endl;
    cout<<"please enter the date and height of vault 2"<<endl;
    cout<<"date:"<<endl;
    cin>>date2<<endl;
    cout<<"height:"<<endl;
    cin>>pole2<<endl;
    cout<<"please enter the date and height of vault 3"<<endl;
    cout<<"date:"<<endl;
    cin>>date3<<endl;
    cout<<"height:"<<endl;
    cin>>pole3<<endl;
                
                
    //argument
    if (5>pole1, pole2, pole3>2) 
        cout<<"sorry but the height is impossible"<<endl;
        cout<<"please restart nd eneter plausibe heights"<<endl;
    if (pole1>pole2>pole3)
        cout<<name<<" best jumps are listed as:"<<endl;
        cout<<pole1<<" on "<<date1<<endl;
        cout<<pole2<<" on "<<date2<<endl;
        cout<<pole3<<" on "<<date3<<endl;
    if (pole3>pole2>pole1)
        cout<<name<<" best jumps are listed as:"<<endl;
        cout<<pole3<<" on "<<date3<<endl;
        cout<<pole2<<" on "<<date2<<endl;
        cout<<pole1<<" on "<<date1<<endl;
    if (pole3>pole1>pole2)
        cout<<name<<" best jumps are listed as:"<<endl;
        cout<<pole3<<" on "<<date3<<endl;
        cout<<pole1<<" on "<<date1<<endl;
        cout<<pole2<<" on "<<date2<<endl;
    if (pole1>pole3>pole2)
        cout<<name<<" best jumps are listed as:"<<endl;
        cout<<pole1<<" on "<<date1<<endl;
        cout<<pole3<<" on "<<date3<<endl;
        cout<<pole2<<" on "<<date2<<endl;
    if (pole2>pole1>pole3)
        cout<<name<<" best jumps are listed as:"<<endl;
        cout<<pole2<<" on "<<date2<<endl;
        cout<<pole1<<" on "<<date1<<endl;
        cout<<pole3<<" on "<<date3<<endl;
    if (pole2>pole3>pole1)
        cout<<name<<" best jumps are listed as:"<<endl;
        cout<<pole2<<" on "<<date2<<endl;
        cout<<pole3<<" on "<<date3<<endl;
        cout<<pole1<<" on "<<date1<<endl;   
                  
    //exit the program  
    
    return 0;
}

    case magdat:
{
    // declare variables
    int year, month, day; // year, month, and day
    int magic; // used to determine if true or not
 
    // user information
    cout<<"please enter a numeric day"<<endl;
    cin>>day<<endl;
    cout<<"please enter a numeric month"<<endl;
    cin>>month<<endl;
    cout<<"please enter a two digit year"<<endl;
    cin>>year<<endl;
    
    //calculations
    magic = month*day;
       
    //argument
    if(magic=year)
        cout<<"congratulations, you have discovered a magic date"<<endl;
    else
        cout<<"unfortunately, that is not a magic date"<<endl;
    
    
    return 0;
}
    case bmi: 
{
    // declare variables
    float bmi, wght, hght; // BMI, weight,; and height
     
    // user information
    cout<<"please enter your weight"<<endl;
    cin>>wght<<endl;
    cout<<"please enter your height (ex 5.5)"<<endl;
    cin>>hght<<endl;

    //calculations
    bmi = wght*703/(hght*hght);
       
    //argument
    if (25>bmi>18.5)
        cout<<"your bmi is optimal:"<<bmi<<endl;
    if (bmi<18.5)
        cout<<"your bmi is underweight:"<<bmi<<endl;
    if(bmi>25)
        cout<<"your bmi is overweight:"<<endl;
   
    
    
    return 0;
}
    return 0;
}
