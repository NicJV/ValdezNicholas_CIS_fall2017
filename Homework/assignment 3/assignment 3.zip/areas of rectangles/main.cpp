/* 
 * File:   main.cpp
 * Author: Nicholas Valdez
  * Created on October , 2017, 8:30pm
 * purpose: which triangle has the greater area
 */

//system libraries
#include <iostream>     //Input/Output library
using namespace std;   // standard name-space under which system libraries reside

// user libraries

// global constants - not variables only math/science/conversions constants

// function prototypes

//execution begins here:
int main(int argc, char** argv) {
    // declare variables
    int area1, area2; // this allows us to store the two ares to solve the problem
    int lnth1, lnth2; // needed for the area
    int wdth1, wdth2; // needed for the area 
    
    // user information
    cout<<"please provide the length of traingle 1 and traingle 2"<<endl;
    cout<<"traingle 1 length is: "<<endl;
    cin>>lnth1<<endl;
    cout<<"traingle 2 length is: "<<endl;
    cin>>lnth2<<endl;
    cout<<"please provide the width of traingle 1 and traingle 2"<<endl;
    cout<<"traingle 1 width is: "<<endl;
    cin>>wdth1<<endl;
    cout<<"traingle 2 width is: "<<endl;
    cin>>wdth2<<endl;
    
    // calculations
    area1 = lnth1 * wdth1;
    area2 = lnth2 * wdth2;
    
    //argument
    if (area1>area2)
        cout<<"traingle 1 is greater than traingle 2"<<endl;
                cout<<area1<<","<<area2<<endl;
    if (area2>area1)
        cout<<"traingle 2 is greater than triangle 1"<<endl;
                cout<<area2<<","<<area1<<endl;
    if (area1=area2)
        cout<<"traingle 1 and traingle 2 are equal"<<endl;
               cout<<area1<<","<<area2<<endl; 
    
    
    
    
    //exit the program  
    
    return 0;
}

