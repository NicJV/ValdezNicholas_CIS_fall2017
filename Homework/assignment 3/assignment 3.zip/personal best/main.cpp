/* 
 * File:   main.cpp
 * Author: Nicholas Valdez
  * Created on October , 2017, 8:30pm
 * purpose: to determine cost of buying bulk software
 */

//system libraries
#include <iostream>     //Input/Output library
#include <cmath>       // used for calculations
using namespace std;   // standard name-space under which system libraries reside

// user libraries

// global constants - not variables only math/science/conversions constants


// function prototypes

//execution begins here:
int main(int argc, char** argv) {
    // declare variables
    float prc1, prc2, prc3, prc4; 
    // different prices for different amount bought
    int quant; // quantity bought
    int sprc; // stnadard price
    
    //initialize
    sprc = 99; // given by problem
    
    // user information
    cout<<"the software being purchased offers a discount on bulk sales"<<endl;
    cout<<" please enters the amount of software you wna to purchase"<<endl;
    cin>>quant<<endl;
                
    //argument
    if (quant<10)
        cout<<" sorry no discount"
        cout<<"your total price is $ "<<sprc<<endl;
    if (19>quant>=10)
        cout<<"you have received a discount of 20%"<<endl;
            prc1 = sprc*.2
        cout<<"your total price is $ "<<prc1<<endl;
    if (49>quant>=20)
        cout<<"you have received a discount of 30%"<<endl;
            prc2 = sprc*.3
        cout<<"your total price is $ "<<prc2<<endl;
    if (99>=quant>=50)
        cout<<"you have recieved a discount of 40%"
                prc3 = sprc*.4
        cout<<"your total price is $ "<<prc3<<endl;
    if (quant>=100)
        cout<<"you have received a discount of 50%"<<endl;
            prc1 = sprc*.5
        cout<<"your total price is $ "<<prc4<<endl;
   
        
        
   
                  
    //exit the program  
    
    return 0;
}

