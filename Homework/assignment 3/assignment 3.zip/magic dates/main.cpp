/* 
 * File:   main.cpp
 * Author: Nicholas Valdez
  * Created on October , 2017, 8:30pm
 * purpose: determine magic dates
 */

//system libraries
#include <iostream>     //Input/Output library
#include <cmath>       // used for calculations
using namespace std;   // standard name-space under which system libraries reside

// user libraries

// global constants - not variables only math/science/conversions constants


// function prototypes

//execution begins here:
int main(int argc, char** argv) {
    // declare variables
    int year, month, day; // year, month, and day
    int magic; // used to determine if true or not
 
    // user information
    cout<<"please enter a numeric day"<<endl;
    cin>>day<<endl;
    cout<<"please enter a numeric month"<<endl;
    cin>>month<<endl;
    cout<<"please enter a two digit year"<<endl;
    cin>>year<<endl;
    
    //calculations
    magic = month*day;
       
    //argument
    if(magic=year)
        cout<<"congratulations, you have discovered a magic date"<<endl;
    else
        cout<<"unfortunately, that is not a magic date"<<endl;
    
    
    return 0;
}
