/* 
 * File:   main.cpp
 * Author: Nicholas Valdez
  * Created on October , 2017, 8:30pm
 * purpose: body mass index
 */

//system libraries
#include <iostream>     //Input/Output library
#include <cmath>       // used for calculations
using namespace std;   // standard name-space under which system libraries reside

// user libraries

// global constants - not variables only math/science/conversions constants


// function prototypes

//execution begins here:
int main(int argc, char** argv) {
    // declare variables
    float bmi, wght, hght; // BMI, weight,; and height
     
    // user information
    cout<<"please enter your weight"<<endl;
    cin>>wght<<endl;
    cout<<"please enter your height (ex 5.5)"<<endl;
    cin>>hght<<endl;

    //calculations
    bmi = wght*703/(hght*hght);
       
    //argument
    if (25>bmi>18.5)
        cout<<"your bmi is optimal:"<<bmi<<endl;
    if (bmi<18.5)
        cout<<"your bmi is underweight:"<<bmi<<endl;
    if(bmi>25)
        cout<<"your bmi is overweight:"<<endl;
   
    
    
    return 0;
}
