/* 
 * File:   main.cpp
 * Author: Nicholas Valdez
  * Created on October , 2017, 8:30pm
 * purpose: 
 */

//system libraries
#include <iostream>     //Input/Output library
#include <cmath>       // used for calculations
using namespace std;   // standard name-space under which system libraries reside

// user libraries

// global constants - not variables only math/science/conversions constants


// function prototypes

//execution begins here:
int main(int argc, char** argv) {
    // declare variables
    int newt, wght // newtons and wght
    
    // user information
    cout<<"please provide the wight of object"<<endl;
    cin>>wght<<endl;
    
    //calculations
    newt = wght*9.8
             
    //argument
    if (newt>1000)
        cout<<"the object is too heavy "<<endl;
    if (10>newt)
        cout<<"the object is too light"<<endl;
    else
        cout<<newt<<" this is your mass in newtons"<<endl;
   
        
        
   
                  
    //exit the program  
    
    return 0;
}

