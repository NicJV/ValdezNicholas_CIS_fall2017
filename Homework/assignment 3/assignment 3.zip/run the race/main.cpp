/* 
 * File:   main.cpp
 * Author: Nicholas Valdez
  * Created on October , 2017, 8:30pm
 * purpose: who won the race
 */

//system libraries
#include <iostream>     //Input/Output library
#include <cmath>       // used for calculations
using namespace std;   // standard name-space under which system libraries reside

// user libraries

// global constants - not variables only math/science/conversions constants


// function prototypes

//execution begins here:
int main(int argc, char** argv) {
    // declare variables
    int run1, run2, run3; // runner 1, 2, and 3
    float time1, time2, time3; // time for 1, 2, and 3
    
    // user information
    cout<<"please provide the name of runner 1"<<endl;
    cin>>run1<<endl;
    cout<<"please provide the time of runner 1"<<endl;
    cin>>time1<<endl;
    cout<<"please provide the name of runner 2"<<endl;
    cin>>run2<<endl;
    cout<<"please provide the time of runner 2"<<endl;
    cin>>time2<<endl;
    cout<<"please provide the name of runner 3"<<endl;
    cin>>run3<<endl;
    cout<<"please provide the time of runner 3"<<endl;
    cin>>time3<<endl;
         
    //argument
    if (time1>time2>time3)
        cout<<"the winning order is: "<<endl;
        cout<<run1<<","<<run2<<","<<run3<<endl;
    if (time3>time2>time1)
        cout<<"the winning order is: "<<endl;
        cout<<run3<<","<<run2<<","<<run1<<endl;
    if (time1>time3>time2)
        cout<<"the winning order is: "<<endl;
        cout<<run1<<","<<run3<<","<<run2<<endl;
    if (time3>time1>time2)
        cout<<"the winning order is: "<<endl;
        cout<<run3<<","<<run1<<","<<run2<<endl; 
    if (time2>time3>time1)
        cout<<"the winning order is: "<<endl;
        cout<<run2<<","<<run3<<","<<run1<<endl;
    if (time2>time1>time3)
        cout<<"the winning order is: "<<endl;
        cout<<run2<<","<<run1<<","<<run3<<endl;
    if (time1, time2, time3 <=0)
        cout<<"impossible time, please follow instructions"<<endl;
        
        
   
                  
    //exit the program  
    
    return 0;
}

